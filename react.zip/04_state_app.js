class Counter extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      count: 0
    }
    // this.addCount = this.addCount.bind(this);
    this.autoCount();
  }

  autoCount(){
    // var self = this;
    // setInterval(function(){
    //   self.setState({
    //     count: self.state.count + 1,
    //   });
    // },1000);
    setInterval(()=>{
      this.setState({
        count: this.state.count + 1,
      });
    },1000);
  }

  addCount() {
    // console.log(this);
    // console.log(123);
    // this.state.count += 1;
    this.setState({
      count: this.state.count + 1,
    });
  }
  render () {
    return (
      <div className="counter">
        <h1>Counter</h1>
        <div className="count">{this.state.count}</div>
        <button onClick={this.addCount}>+1</button>
      </div>
    );
  }
}
ReactDOM.render(
  <Counter/>,
  document.getElementById('app')
);


// function foo(){
//   console.log(this);
// }
// foo();

// foo.call(window);

// var a = {name:'milkmidi'};
// foo.apply(a);