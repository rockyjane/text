import React from 'react';
import TodoList from './components/TodoList';
import './app.css';


function delay() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve();
    }, 1000);
  });
}

function start() {
  delay()
    .then(() => delay())
    .then(() => delay())
    .then(() => {
      console.log('promise resolve');
    });
}
start();

const start2 = async () => {
  await delay();
  await delay();
  await delay();
  console.log('async');
};
start2();


/* var delay = (time ) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve();
    },time)
  });
} */


const App = () => (
  <div className="app">
    <TodoList />
  </div>
);

export default App;
